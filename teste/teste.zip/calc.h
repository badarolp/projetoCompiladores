void yyerror (char *s);

int symbols[52];

int symbolVal(char symbol);

void updateSymbolVal(char symbol, int val);

//int computeSymbolIndex(char token):
